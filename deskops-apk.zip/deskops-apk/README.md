# 桌面运维学习导师（APK 构建仓库）

- `www/index.html`：App 本体（单文件，界面和功能与网页版完全一致）
- `.github/workflows/build-apk.yml`：GitHub 自动构建 APK
- 构建结果：仓库 → Actions → 最新一次运行 → Artifacts → `deskops-apk`
